/**
 * http://usejsdoc.org/
 */

function getcity() {
	var xmlhttp;

	var state = document.getElementById("state").value;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			document.getElementById("city").innerHTML = xmlhttp.responseText;
		}

	};

	var url = "cityServlet?state=" + escape(state);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function getpersonalInfo() {
	var xmlhttp;

	var personalid = document.getElementById("oldpatientid").value;
	if(personalid=="")
		{
		alert("Old Personal Id is Empty");
		return;
		}
	var personalidnew = document.getElementById("newpatientid").value;
	
	document.getElementById("patientidold").value=personalid;
	document.getElementById("newpatientid").value=personalidnew;

	var parser, xmldoc;
	parser = new DOMParser();

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			
			

			xmlDoc = parser.parseFromString(xmlhttp.responseText, "text/xml");
			document.getElementById("pid").value = xmlDoc
			.getElementsByTagName("pid")[0].childNodes[0].nodeValue;
			document.getElementById("fname").value = xmlDoc
					.getElementsByTagName("fname")[0].childNodes[0].nodeValue;
			document.getElementById("lname").value = xmlDoc
					.getElementsByTagName("lname")[0].childNodes[0].nodeValue;
			document.getElementById("DOB").value = xmlDoc
					.getElementsByTagName("dob")[0].childNodes[0].nodeValue;
			// document.getElementById("gender").value =
			document.personalInfo.gender.value = xmlDoc
					.getElementsByTagName("gender")[0].childNodes[0].nodeValue;
			document.getElementById("relation").value = xmlDoc
					.getElementsByTagName("relation")[0].childNodes[0].nodeValue;
			document.getElementById("rname").value = xmlDoc
					.getElementsByTagName("rname")[0].childNodes[0].nodeValue;
			// document.getElementById("married").value =
			document.personalInfo.married.value = xmlDoc
					.getElementsByTagName("married")[0].childNodes[0].nodeValue;
			document.getElementById("age").value = xmlDoc
					.getElementsByTagName("age")[0].childNodes[0].nodeValue;

		}

	};

	var url = "getPersonalInfoServlet?personalinfoid=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function geteduOccupation() {
	var xmlhttp;

	var personalid = document.getElementById("oldpatientid").value;
	
	if(personalid=="")
	{
	
	return;
	}

	var parser, xmldoc;
	parser = new DOMParser();

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			xmlDoc = parser.parseFromString(xmlhttp.responseText, "text/xml");
			document.getElementById("eid").value = xmlDoc
			.getElementsByTagName("eid")[0].childNodes[0].nodeValue;
			document.getElementById("education").value = xmlDoc
					.getElementsByTagName("education")[0].childNodes[0].nodeValue;
			document.getElementById("occupation").value = xmlDoc
					.getElementsByTagName("occupation")[0].childNodes[0].nodeValue;
			document.getElementById("typeofjob").value = xmlDoc
					.getElementsByTagName("typeofjob")[0].childNodes[0].nodeValue;
			document.getElementById("designation").value = xmlDoc
					.getElementsByTagName("designation")[0].childNodes[0].nodeValue;

		}

	};

	var url = "getEduOccupationServlet?personalinfoid=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function checkpatientexist() {
	var xmlhttp;

	var personalid = document.getElementById("patientId").value;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			if (Number(xmlhttp.responseText) == 0) {
				alert("Patient Id Does Not Exist");
				document.getElementById("addmedicine").disabled = true;
				document.getElementById("resetmedicine").disabled = true;
				document.getElementById("addvisit").disabled = true;

			} else {
				document.getElementById("addmedicine").disabled = false;
				document.getElementById("resetmedicine").disabled = false;
				document.getElementById("addvisit").disabled = false;

			}

		}

	};

	var url = "checkpatientid?patientId=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function checkpatientexist1() {
	var xmlhttp;

	var personalid = document.getElementById("oldpatientid").value;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			if (Number(xmlhttp.responseText) == 0) {
				alert("Patient Id Does Not Exist Please Generate New Id");

			} else {

			}

		}

	};

	var url = "checkpatientid?patientId=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function getvisitno() {
	var xmlhttp;

	var personalid = document.getElementById("patientId").value;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			if (Number(xmlhttp.responseText) == 0) {

				document.getElementById("visitno").value = 1;

			} else {
				document.getElementById("visitno").value = Number(xmlhttp.responseText) + 1;

			}

		}

	};

	var url = "getvisitno?patientId=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function getvisittable() {
	var xmlhttp;

	var personalid = document.getElementById("patientId").value;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			document.getElementById("tablevisit").innerHTML = xmlhttp.responseText;

		}

	};

	var url = "getvisittable?patientId=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function getcontact() {
	var xmlhttp;

	var personalid = document.getElementById("oldpatientid").value;
	if(personalid=="")
	{
	
	return;
	}

	var parser, xmldoc;
	parser = new DOMParser();

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			xmlDoc = parser.parseFromString(xmlhttp.responseText, "text/xml");
			document.getElementById("cid").value = xmlDoc
			.getElementsByTagName("cid")[0].childNodes[0].nodeValue;
			document.getElementById("address").value = xmlDoc
					.getElementsByTagName("address")[0].childNodes[0].nodeValue;
			document.getElementById("state").value = xmlDoc
					.getElementsByTagName("state")[0].childNodes[0].nodeValue;
			document.getElementById("city").innerHTML = "<option>"
					+ xmlDoc.getElementsByTagName("city")[0].childNodes[0].nodeValue;

			document.getElementById("pincode").value = xmlDoc
					.getElementsByTagName("pincode")[0].childNodes[0].nodeValue;
			document.getElementById("mobile").value = xmlDoc
					.getElementsByTagName("mobile")[0].childNodes[0].nodeValue;
			document.getElementById("email").value = xmlDoc
					.getElementsByTagName("email")[0].childNodes[0].nodeValue;

		}

	};

	var url = "getContactServlet?personalinfoid=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function fetchsearch() {
	var xmlhttp;

	var searchtext = document.getElementById("searchtext").value;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			document.getElementById("searchresult").innerHTML = xmlhttp.responseText;

		}
	};
	var url = "getsearchdetails?searchtext=" + escape(searchtext);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function searchdisordersymptom() {
	var xmlhttp;

	var searchtextsd = document.getElementById("searchtextsd").value;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			document.getElementById("searchresultsd").innerHTML = xmlhttp.responseText;

		}
	};
	var url = "getvisitdata?searchtextsd=" + escape(searchtextsd);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}


function listpatdisorders() {
	var xmlhttp;

	var searchtextd = document.getElementById("disorderlist").value;
	var startdate=document.getElementById("startdate").value;
	var enddate=document.getElementById("enddate").value;
	

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			document.getElementById("resultdisorders").innerHTML = xmlhttp.responseText;
			document.getElementById("disorderlist").value="";

		}
	};
	var url = "getvisitdatadate?searchtextsd=" + escape(searchtextd)+ "&startdate=" + escape(startdate)+ "&enddate=" + escape(enddate);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}


function listpatsymptoms() {
	var xmlhttp;

	var searchtexts = document.getElementById("symptomlist").value;
	var startdate=document.getElementById("startdate").value;
	var enddate=document.getElementById("enddate").value;
	

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			document.getElementById("resultsymptoms").innerHTML = xmlhttp.responseText;
			document.getElementById("symptomlist").value="";

		}
	};
	var url = "getvisitdatadate?searchtextsd=" + escape(searchtexts)+ "&startdate=" + escape(startdate)+ "&enddate=" + escape(enddate);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}


function listmedpresc() {
	var xmlhttp;

	var searchmed = document.getElementById("medicinelist").value;
	var startdate=document.getElementById("startdate").value;
	var enddate=document.getElementById("enddate").value;
	

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			document.getElementById("resultmedpresc").innerHTML = xmlhttp.responseText;
			document.getElementById("medicinelist").value="";

		}
	};
	var url = "getmedicinepresc?searchtextsd=" + escape(searchmed)+ "&startdate=" + escape(startdate)+ "&enddate=" + escape(enddate);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}


function checkusrpass() {
	var xmlhttp;
	
	
	

	var uname = document.getElementById("username").value;
	
	
	var pword = document.getElementById("password").value;
	
	var newpword = document.getElementById("newpassword").value;
	var conpword = document.getElementById("conpassword").value;
	
	
	if(newpword!=conpword)
		{
		alert("New Password and Confirm Password Mismatch");
		}

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			if (Number(xmlhttp.responseText) != 0 && Number(xmlhttp.responseText) != -1) {
				alert("Password Successfully Changed");
				
				window.location = "initial.jsp";

			} else if(Number(xmlhttp.responseText) == -1) {
				alert("Wrong Username or Password");
				window.location = "changepass"
			} else if(Number(xmlhttp.responseText) == 0)
				{
				alert("Password Not Changed");
				}

		}

	};

	var url = "isUserExist";
	xmlhttp.open("POST", url, true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send("username="+uname+"&password="+pword+"&newpassword="+newpword);
	xmlhttp.send();
}


function updatepi() {
	var xmlhttp;
	
	
	var pid = document.getElementById("pid").value;
	var patientId = document.getElementById("oldpatientid").value;
	
	var fname = document.getElementById("fname").value;
	var lname = document.getElementById("lname").value;
	var DOB = document.getElementById("DOB").value;
	
	var ele = document.getElementsByName('gender'); 
    
    for(i = 0; i < ele.length; i++) { 
        if(ele[i].checked) 
        var gender = ele[i].value; 
    } 
	
	//var gender = document.getElementById("gender").value;
	
	var relation = document.getElementById("relation").value;
	var rname = document.getElementById("rname").value;
	
	
var marr = document.getElementsByName('married'); 
    
    for(i = 0; i < ele.length; i++) { 
        if(marr[i].checked) 
        var married = marr[i].value; 
    } 
    
	
	
	//var married = document.getElementById("married").value;
	var age = document.getElementById("age").value;
	
	var eid = document.getElementById("eid").value;
	var education = document.getElementById("education").value;
	var occupation = document.getElementById("occupation").value;
	var typeofjob = document.getElementById("typeofjob").value;
	var designation = document.getElementById("designation").value;
	
	
	var cid = document.getElementById("cid").value;
	var address = document.getElementById("address").value;
	var state = document.getElementById("state").value;
	var city = document.getElementById("city").value;
	var pincode = document.getElementById("pincode").value;
	var email = document.getElementById("email").value;
	var mobile = document.getElementById("mobile").value;
	
	
	

	

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			
			alert("Personal Information Updated Successfully");

			

		}

	};

	var url = "personalinfoUpdateServlet";
	xmlhttp.open("POST", url, true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send("pid="+pid+"&patientId="+patientId+"&fname="+fname+"&lname="+lname+"&DOB="+DOB+"&gender="+gender
			+"&relation="+relation+"&rname="+rname+"&married="+married+"&age="+age+"&eid="+eid+"&education="+education
			+"&occupation="+occupation+"&typeofjob="+typeofjob+"&designation="+designation+"&cid="+cid+"&address="+address+
			"&state="+state+"&city="+city+"&pincode="+pincode+"&email="+email+"&mobile="+mobile);
	xmlhttp.send();
}






function UserExists() {
	var xmlhttp;
	
	
	

	var uname = document.getElementById("username").value;
	
	
	
	
	
	

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			
			
			//return xmlhttp.responseText;

			 if(Number(xmlhttp.responseText) == 1) {
				alert("User Already Exists");
				return false;
				
				
			}if (Number((xmlhttp.responseText) == 0)){
				if (confirm("User Available continue")==true)
				{
					$("#submituser").submit();
				}
			}
			            
	    }
				


			
		

	};

	var url = "UserExists";
	xmlhttp.open("POST", url, true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send("username="+uname);
	xmlhttp.send();
	}
