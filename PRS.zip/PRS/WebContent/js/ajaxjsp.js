/**
 * http://usejsdoc.org/
 */

function getcity() {
	var xmlhttp;

	var state = document.getElementById("state").value;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			document.getElementById("city").innerHTML = xmlhttp.responseText;
		}

	};

	var url = "cityServlet?state=" + escape(state);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function getpersonalInfo() {
	var xmlhttp;

	var personalid = document.getElementById("oldpatientid").value;
	

	var parser, xmldoc;
	parser = new DOMParser();

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			
			xmlDoc = parser.parseFromString(xmlhttp.responseText, "text/xml");
			document.getElementById("fname").value = xmlDoc
					.getElementsByTagName("fname")[0].childNodes[0].nodeValue;
			document.getElementById("lname").value = xmlDoc
					.getElementsByTagName("lname")[0].childNodes[0].nodeValue;
			document.getElementById("DOB").value = xmlDoc
					.getElementsByTagName("dob")[0].childNodes[0].nodeValue;
			// document.getElementById("gender").value =
			document.personalInfo.gender.value = xmlDoc
					.getElementsByTagName("gender")[0].childNodes[0].nodeValue;
			document.getElementById("relation").value = xmlDoc
					.getElementsByTagName("relation")[0].childNodes[0].nodeValue;
			document.getElementById("rname").value = xmlDoc
					.getElementsByTagName("rname")[0].childNodes[0].nodeValue;
			// document.getElementById("married").value =
			document.personalInfo.married.value = xmlDoc
					.getElementsByTagName("married")[0].childNodes[0].nodeValue;
			document.getElementById("age").value = xmlDoc
					.getElementsByTagName("age")[0].childNodes[0].nodeValue;

		}

	};

	var url = "getPersonalInfoServlet?personalinfoid=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function geteduOccupation() {
	var xmlhttp;

	var personalid = document.getElementById("oldpatientid").value;
	

	var parser, xmldoc;
	parser = new DOMParser();

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			
			xmlDoc = parser.parseFromString(xmlhttp.responseText, "text/xml");
			document.getElementById("education").value = xmlDoc
					.getElementsByTagName("education")[0].childNodes[0].nodeValue;
			document.getElementById("occupation").value = xmlDoc
					.getElementsByTagName("occupation")[0].childNodes[0].nodeValue;
			document.getElementById("typeofjob").value = xmlDoc
					.getElementsByTagName("typeofjob")[0].childNodes[0].nodeValue;
			document.getElementById("designation").value = xmlDoc
					.getElementsByTagName("designation")[0].childNodes[0].nodeValue;

		}

	};

	var url = "getEduOccupationServlet?personalinfoid=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function checkpatientexist() {
	var xmlhttp;

	var personalid = document.getElementById("patientId").value;
	

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			if (Number(xmlhttp.responseText) == 0) {
				alert("Patient Id Does Not Exist");
				document.getElementById("addmedicine").disabled = true;
				document.getElementById("resetmedicine").disabled = true;
				document.getElementById("addvisit").disabled = true;

			} else {
				document.getElementById("addmedicine").disabled = false;
				document.getElementById("resetmedicine").disabled = false;
				document.getElementById("addvisit").disabled = false;

			}

		}

	};

	var url = "checkpatientid?patientId=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function getvisitno() {
	var xmlhttp;

	var personalid = document.getElementById("patientId").value;
	

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			
			if (Number(xmlhttp.responseText) == 0) {

				document.getElementById("visitno").value = 1;

			} else {
				document.getElementById("visitno").value = Number(xmlhttp.responseText) + 1;

			}
			

		}

	};

	var  url = "getvisitno?patientId=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function getvisittable() {
	var xmlhttp;

	var personalid = document.getElementById("patientId").value;
	

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			

			document.getElementById("tablevisit").innerHTML = xmlhttp.responseText;

		}

	};

	var url = "getvisittable?patientId=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function getcontact() {
	var xmlhttp;

	var personalid = document.getElementById("oldpatientid").value;
	

	var parser, xmldoc;
	parser = new DOMParser();

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {

			
			xmlDoc = parser.parseFromString(xmlhttp.responseText, "text/xml");
			document.getElementById("address").value = xmlDoc
					.getElementsByTagName("address")[0].childNodes[0].nodeValue;
			document.getElementById("state").value = xmlDoc
					.getElementsByTagName("state")[0].childNodes[0].nodeValue;
			document.getElementById("city").innerHTML = "<option>"
					+ xmlDoc.getElementsByTagName("city")[0].childNodes[0].nodeValue;
			
			document.getElementById("pincode").value = xmlDoc
					.getElementsByTagName("pincode")[0].childNodes[0].nodeValue;
			document.getElementById("mobile").value = xmlDoc
					.getElementsByTagName("mobile")[0].childNodes[0].nodeValue;
			document.getElementById("email").value = xmlDoc
					.getElementsByTagName("email")[0].childNodes[0].nodeValue;

		}

	};

	var url = "getContactServlet?personalinfoid=" + escape(personalid);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}

function fetchsearch()
{
    var xmlhttp;
    
    var searchtext = document.getElementById("searchtext").value;
    

    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    } else
    {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function ()
    {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200)
        {
            
            document.getElementById("searchresult").innerHTML = xmlhttp.responseText;
            
        }
    };
    var url = "getsearchdetails?searchtext=" + escape(searchtext);
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}



