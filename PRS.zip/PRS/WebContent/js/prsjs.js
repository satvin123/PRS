$(document).ready(function() {
	$(page1).hide();
	$(page3).hide();
	// when page1Link link is clicked, page1 shows,
	// page2 hides
	$(page1Link).bind("click", function() {
		$(page1).show();
		$(page2).hide();
		$(page3).hide();
	});

	// when page2Link link is clicked, page2 shows,
	// page1 hides
	$(page2Link).bind("click", function() {
		$(page1).hide();
		$(page2).show();
		$(page3).hide();
	});

	$(page3Link).bind("click", function() {
		$(page1).hide();
		$(page2).hide();
		$(page3).show();
	});
});

$(function() {
	var $select = $(".age");
	for (i = 1; i <= 100; i++) {
		$select.append($('<option></option>').val(i + " Years").html(
				i + " Years"))
	}
});

function genid() {
	var today = new Date();

	var month1 = today.getMonth() + 1;
	if ((today.getMonth() + 1) < 10)
		month1 = "0" + (today.getMonth() + 1);
	var date1 = today.getDate();
	if ((today.getDate()) < 10)
		date1 = "0" + today.getDate();
	var hours1 = today.getHours();
	if ((today.getHours) < 10)
		hours1 = "0" + today.getHours();
	var minutes1 = today.getMinutes();
	if ((today.getMinutes) < 10)
		minutes1 = "0" + today.getMinutes;
	var seconds1 = today.getSeconds();
	if (Number(seconds1) < 10) {
		seconds1 = "0" + today.getSeconds();
	}

	var date = date1 + "" + month1 + "" + today.getFullYear() + "" + hours1
			+ "" + minutes1 + "" + seconds1;
	document.getElementById("newpatientid").value = date;
	document.getElementById("patientidnew").value = date;
	document.getElementById("patientidnew1").value = date;
	document.getElementById("patientidnew2").value = date;
	alert(document.getElementById("patientidnew2").value);
}

function addMed() {
	
	if (document.getElementById("medicinelist").value=="")
	{
	alert("Please Select or Enter Medicine");
	return;
	}

	var serial = Number(document.getElementById("serial").value) + 1;
	document.getElementById("serial").value = serial;
	// document.getElementById("sno").value=serial-1;
	var medicinelist = document.getElementById("medicinelist").value;
	var dosage = document.getElementById("dosage").value;
	var morning = document.getElementById("morning");
	var afternoon = document.getElementById("afternoon");
	var night = document.getElementById("night");
	var aftermeals = document.getElementById("aftermeals");
	var timing = "";
	if (morning.checked == true) {
		timing = "morning";
	}
	if (afternoon.checked == true) {
		timing = timing + ":afternoon";
	}
	if (night.checked == true) {
		timing = timing + ":night";
	}
	if (aftermeals.checked == true) {
		timing = timing + ":aftermeals";
	}
	

	var table = document.getElementById("medTable");
	var row = table.insertRow(2);
	var cell1 = row.insertCell(0);
	var cell2 = row.insertCell(1);
	var cell3 = row.insertCell(2);
	var cell4 = row.insertCell(3);

	cell1.innerHTML = "<input class=\"sno\" name=\"sno" + (serial - 1)
			+ "\" id=\"sno" + (serial - 1) + "\" type=\"text\" value=\""
			+ (serial - 1) + "\" readonly=\"true\"/>";
	cell2.innerHTML = "<input name=\"medicinelist" + (serial - 1)
			+ "\" id=\"medicinelist" + (serial - 1)
			+ "\" type=\"text\" value=\"" + medicinelist
			+ "\" readonly=\"true\"/>";
	cell3.innerHTML = "<input name=\"dosage" + (serial - 1) + "\" id=\"dosage"
			+ (serial - 1) + "\" type=\"text\" value=\"" + dosage
			+ "\" readonly=\"true\"/>";
	cell4.innerHTML = "<input  name=\"timing" + (serial - 1) + "\" id=\"timing"
			+ (serial - 1) + "\" type=\"text\" value=\"" + timing
			+ "\" readonly=\"true\"/>";
	
	document.getElementById("medicinelist").value="";

	return;

}

function resetMed() {

	var serial = Number(document.getElementById("serial").value);

	var table = document.getElementById("medTable");

	while (serial > 1) {
		table.deleteRow(serial);
		document.getElementById("serial").value = serial - 1;
		serial = serial - 1;
	}

	document.getElementById("sno").value = 0;

	return;
}

function checkId()
{
var genpatientid=document.getElementById("newpatientid").value;
var oldpatientid=document.getElementById("oldpatientid").value;


if(genpatientid=="" && oldpatientid=="" )
	{
	alert("Please Generate New ID or Enter Old Patient ID");
	return;
	}




}






function copytoclipboard() {
	
	  /* Get the text field */
	  var copyText = document.getElementById("copytoclip");
	  

	  /* Select the text field */
	  copyText.select();
	  copyText.setSelectionRange(0, 99999); /*For mobile devices*/

	  /* Copy the text inside the text field */
	  document.execCommand("copy");

	  /* Alert the copied text */
	  alert("Copied the Id: " + copyText.value);
	}
