package com.prs.servlet;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.log.Logger;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;
import com.prs.dclass.pdfgenmodel;

/**
 * Servlet implementation class PDFServlet
 */
@WebServlet("/PDFServlet")
public class PDFServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PDFServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
    try (PrintWriter out = response.getWriter()) {
            
            Document document = new Document(PageSize.A4);

            try {
                //File file = new File("/home/satvinso/pdfhome/prescription.pdf");
                File file = new File("C:\\project\\prescription.pdf");
                PdfWriter pdfWriter = PdfWriter.getInstance(document, new FileOutputStream(file));
                document.open();
                //Image img11 = Image.getInstance("/home/satvinso/pdfhome/logo.png");
                Image img11 = Image.getInstance("C:\\project\\logo.png");
                img11.scaleAbsolute(95, 65);
                document.add(img11);
                
                PdfContentByte canvas = pdfWriter.getDirectContent();
               // Rectangle rect = new Rectangle(110, 815, 557, 740);
               // rect.setBackgroundColor(BaseColor.LIGHT_GRAY);
               // canvas.rectangle(rect);
                

                pdfgenmodel.FixTextBold("Dr. Vaibhav Dubey", 200, 790, pdfWriter, 10);
                pdfgenmodel.FixText("MBBS, MD (Psychiatry)", 200, 778, pdfWriter, 8);
                pdfgenmodel.FixText("Clinic Between Polytechnic Square and Kilol Park Petrol Pump", 200, 766, pdfWriter, 8);
                pdfgenmodel.FixText("Near Angithi Restaurant, Bhopal- 462002 MP (India)", 200, 754, pdfWriter, 8);
                pdfgenmodel.FixText("Mobile- +91 9424401688 E-mail - dr.vaibhavdubey@gmail.com", 200, 743, pdfWriter, 8);
                pdfgenmodel.FixTextBold("____________________________________________________________________________________", 200, 743, pdfWriter, 8);
                document.close();

            }
            catch (DocumentException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
