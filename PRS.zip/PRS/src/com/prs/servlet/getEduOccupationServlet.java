package com.prs.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.eduoccupationDB;
import com.prs.dbclass.personalInfoDB;
import com.prs.model.eduOccupation;
import com.prs.model.personalInfo;

/**
 * Servlet implementation class getEduOccupationServlet
 */
@WebServlet("/getEduOccupationServlet")
public class getEduOccupationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getEduOccupationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
         response.setContentType("text/xml");
        
         eduoccupationDB eduoccupDB = new eduoccupationDB();
        String personalid=request.getParameter("personalinfoid");
        eduOccupation eduoccup = eduoccupDB.geteduoccupation(personalid);

        try (PrintWriter out = response.getWriter()) {

            StringBuffer sb = new StringBuffer();
            sb.append("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
            sb.append("<eduOccupation>");
            sb.append("<personalinfoid>" + eduoccup.getPersonalinfoid() + "</personalinfoid>\n");
            sb.append("<education>" + eduoccup.getEducation() + "</education>\n");
            sb.append("<occupation>" + eduoccup.getOccupation()+ "</occupation>\n");
            sb.append("<typeofjob>" + eduoccup.getTypeofjob() + "</typeofjob>\n");
            sb.append("<designation>" + eduoccup.getDesignation() + "</designation>\n");
            
            sb.append("</eduOccupation>");
            System.out.println(sb.toString());
            out.println(sb.toString());
            out.flush();

        }
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
