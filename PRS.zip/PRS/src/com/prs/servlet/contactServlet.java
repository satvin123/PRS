package com.prs.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prs.model.contact;
import com.prs.model.eduOccupation;
import com.prs.model.persistence.HibernateUtil;

/**
 * Servlet implementation class contactServlet
 */
@WebServlet("/contact")
public class contactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public contactServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String newpatient=request.getParameter("patientidnew2");
		System.out.println(newpatient);
		String address=request.getParameter("address");
		String state=request.getParameter("state");
		String city=request.getParameter("city");
		String pincode=request.getParameter("pincode");
		String mobile=request.getParameter("mobile");
		String email=request.getParameter("email");
		
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		 
		
		 Transaction tx = null;	
		 try {
			 tx = session.getTransaction();
			 tx.begin();
			 contact cont=new contact();
			 cont.setPersonalinfoid(newpatient);
			 cont.setAddress(address);
			 cont.setState(state);
			 cont.setCity(city);
			 cont.setPincode(pincode);
			 cont.setMobile(mobile);
			 cont.setEmail(email);
			 
			 
			 session.saveOrUpdate(cont);		
			 tx.commit();
		 } catch (Exception e) {
			 if (tx != null) {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } finally {
			 session.close();
		 }	
		 return;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
