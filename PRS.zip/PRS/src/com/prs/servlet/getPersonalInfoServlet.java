package com.prs.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.personalInfoDB;
import com.prs.model.personalInfo;

/**
 * Servlet implementation class getPersonalInfoServlet
 */
@WebServlet("/getPersonalInfoServlet")
public class getPersonalInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getPersonalInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/xml");
        
        personalInfoDB personalDB = new personalInfoDB();
        String personalid=request.getParameter("personalinfoid");
        personalInfo personal = personalDB.getpersonalInfo(personalid);

        try (PrintWriter out = response.getWriter()) {

            StringBuffer sb = new StringBuffer();
            sb.append("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
            sb.append("<personalInfo>");
            sb.append("<pid>" + personal.getId() + "</pid>\n");
            sb.append("<personalinfoid>" + personal.getPersonalinfoid() + "</personalinfoid>\n");
            sb.append("<fname>" + personal.getFname() + "</fname>\n");
            sb.append("<lname>" + personal.getLname() + "</lname>\n");
            sb.append("<dob>" + personal.getDOB() + "</dob>\n");
            sb.append("<gender>" + personal.getGender() + "</gender>\n");
            sb.append("<relation>" + personal.getRelation() + "</relation>\n");
            sb.append("<rname>" + personal.getRname() + "</rname>\n");
            sb.append("<married>" + personal.getMarried() + "</married>\n");
            sb.append("<age>" + personal.getAge() + "</age>\n");
            sb.append("</personalInfo>");
            System.out.println(sb.toString());
            out.println(sb.toString());
            out.flush();

        }
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
