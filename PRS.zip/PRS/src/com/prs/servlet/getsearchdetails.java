package com.prs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.searchinfoDB;
import com.prs.model.searchinfo;

/**
 * Servlet implementation class getsearchdetails
 */
@WebServlet("/getsearchdetails")
public class getsearchdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getsearchdetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		
		String searchtext=request.getParameter("searchtext");
		searchinfoDB searchinfodb = new searchinfoDB();
		List<searchinfo> searchlist=searchinfodb.listInfo(searchtext);
		
		searchinfo sinfo;
		try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            StringBuffer sb = new StringBuffer();
            sb.append("</br><table class=\"w3-table-all w3-hoverable\" width=\"100px\"align=\"center\">");
            sb.append("<tbody><tr class=\"w3-green\" style=\"height: 40px\"/><th>PatientID</th><th>First Name</th><th>Last Name</th><th>DOB</th><th>Gender</th>");
            sb.append("<th>Relationship</th><th>Relative Name</th><th>Age</th><th>City</th><th>Mobile</th><th>EMail</th></tr></tbody>");
            Iterator iterator = searchlist.iterator();
            while (iterator.hasNext())
            {
                sinfo=(searchinfo)iterator.next();
                
                sb.append("<tr>");
                sb.append("<td>"+sinfo.getPersonalinfoid()+"</td>");
                sb.append("<td>"+sinfo.getFname()+"</td>");
                sb.append("<td>"+sinfo.getLname()+"</td>");
                sb.append("<td>"+sinfo.getDOB()+"</td>");
                sb.append("<td>"+sinfo.getGender()+"</td>");
                sb.append("<td>"+sinfo.getRelation()+"</td>");
                sb.append("<td>"+sinfo.getRname()+"</td>");
                sb.append("<td>"+sinfo.getAge()+"</td>");
                sb.append("<td>"+sinfo.getCity()+"</td>");
                sb.append("<td>"+sinfo.getMobile()+"</td>");
                sb.append("<td>"+sinfo.getEmail()+"</td>");
            }
            sb.append("</tbody></table>");
            out.println(sb.toString());
            out.flush();
        }
		
		
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
