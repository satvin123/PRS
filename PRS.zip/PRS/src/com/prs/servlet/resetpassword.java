package com.prs.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.userDB;
import com.prs.model.userdata;

/**
 * Servlet implementation class resetpassword
 */
@WebServlet("/resetpassword")
public class resetpassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	private String host;
    private String port;
    private String user;
    private String pass;
    
    
    
    public void init() {
        host = "smtp.gmail.com";
        port = "587";
        user = "dhibhopal19@gmail.com";
        pass = "moga78city";
    }
    
    
    
    
    static String getAlphaNumericString(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                    + "0123456789"
                                    + "abcdefghijklmnopqrstuvxyz"
                                    +"!@#$%^&*(){}[]:;<>?,."; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 
    
    
    
    
    public static void sendEmail(String host, String port,
            final String userName, final String password, String toAddress,
            String subject, String message) throws AddressException,
            MessagingException {
 
        // sets SMTP server properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
 
        // creates a new session with an authenticator
        Authenticator auth = new Authenticator() {
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(userName,password);
            }
        };
 
        Session session = Session.getInstance(properties, auth);
 
        // creates a new e-mail message
        Message msg = new MimeMessage(session);
 
        msg.setFrom(new InternetAddress(userName));
        InternetAddress[] toAddresses = { new InternetAddress(toAddress) };
        msg.setRecipients(Message.RecipientType.TO, toAddresses);
        msg.setSubject(subject);
        msg.setSentDate(new Date());
        msg.setText(message);
 
        // sends the e-mail
        Transport.send(msg);
 
    }
	
	
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public resetpassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doPost(request, response);
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		userDB userdb=new userDB();
		String username=request.getParameter("username");
		userdata user1=userdb.UserExists(username);
		
		
		
		String recipient="";
		String subject="Reset New Password";
		
        //String content = request.getParameter("content");
		String resetpass=getAlphaNumericString(6);
		String content="Dr. Vaibhav Dubey \n Welcome to Patient Record System \n Your New Password for User : "+username+"  is :  "+ resetpass;
		if(user1!=null)
		{
			recipient=user1.getEmail();
		userdb.resetPassword(username, resetpass);
		response.getWriter().append("<h1>The Reset Password E-mail was sent successfully</h1>");
		 response.setHeader("Refresh", "2;url=login");
		}
		else
		{
			response.getWriter().append("<h1>The Username does not Exist</h1>");
			 response.setHeader("Refresh", "2;url=forgotpass");
			 return;
		}
		
		
		
 
        String resultMessage = "";
 
        try {
            this.sendEmail(host, port, user, pass, recipient, subject,
                    content);
            resultMessage = "The e-mail was sent successfully";
        } catch (Exception ex) {
            ex.printStackTrace();
            resultMessage = "There were an error: " + ex.getMessage();
        } finally {
			/*
			 * request.setAttribute("Message", resultMessage);
			 * getServletContext().getRequestDispatcher("/Results").forward( request,
			 * response);
			 */
        }
		
		
		
		
		
		
		
		
	}

}
