package com.prs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prs.dbclass.contactDB;
import com.prs.dbclass.personalInfoDB;
import com.prs.dbclass.searchinfoDB;
import com.prs.dbclass.visitdataDB;
import com.prs.model.contact;
import com.prs.model.personalInfo;
import com.prs.model.searchinfo;
import com.prs.model.visitdata;

/**
 * Servlet implementation class getvisitdata
 */
@WebServlet("/getvisitdata")
public class getvisitdata extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getvisitdata() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");

		String searchtextsd = request.getParameter("searchtextsd");
		visitdataDB searchinfodb = new visitdataDB();
		List<visitdata> searchlist = searchinfodb.listInfosd(searchtextsd);

		visitdata visit;
		personalInfo pi;
		personalInfoDB personal = new personalInfoDB();
		contactDB contactdb = new contactDB();
		contact con;
		try (PrintWriter out = response.getWriter()) {
			/* TODO output your page here. You may use following sample code. */
			StringBuffer sb = new StringBuffer();
			sb.append("<table class=\"w3-table-all w3-hoverable\" width=\"100px\"align=\"center\">");
			sb.append(
					"<tbody><tr class=\"w3-green\" style=\"height: 40px\"><th>ID</th><th>Visit No</th><th>Patient ID</th><th>Date Visit</th><th>Name</th><th>Last Name</th>");
			sb.append("<th>Gender</th><th>Age</th><th>City</th><th>Mobile</th><th>EMail</th></tr>");

			Iterator iterator = searchlist.iterator();

			while (iterator.hasNext()) {
				visit = (visitdata) iterator.next();

				pi = personal.getpersonalInfo(visit.getPatientid());
				con = contactdb.getcontact(visit.getPatientid());

				sb.append("<tr>");
				sb.append("<td><a target=\"_blank\" href=\"getvisittabdata?idvisitdata=" + visit.getId() + "\">"
						+ visit.getId() + "</a></td>");

				sb.append("<td>" + visit.getVisitno() + "</td>");
				sb.append("<td>" + visit.getPatientid() + "</td>");
				sb.append("<td>" + visit.getDateofvisit() + "</td>");
				sb.append("<td>" + pi.getFname() + "</td>");
				sb.append("<td>" + pi.getLname() + "</td>");
				sb.append("<td>" + pi.getGender() + "</td>");
				sb.append("<td>" + pi.getAge() + "</td>");
				sb.append("<td>" + con.getCity() + "</td>");
				sb.append("<td>" + con.getMobile() + "</td>");
				sb.append("<td>" + con.getEmail() + "</td>");
				sb.append("</tr>");
			}
			sb.append("</tbody></table>");
			out.println(sb.toString());
			out.flush();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
