package com.prs.servlet;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prs.model.contact;
import com.prs.model.eduOccupation;
import com.prs.model.personalInfo;
import com.prs.model.prescription;
import com.prs.model.visitdata;
import com.prs.model.persistence.HibernateUtil;

/**
 * Servlet implementation class addvisitdata
 */
@WebServlet("/addvisitdata")
public class addvisitdata extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addvisitdata() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");  
		   LocalDateTime now = LocalDateTime.now();  
		   System.out.println(dtf.format(now));
		
		
		
		
		String newpatient=request.getParameter("patientidnew");
		
		String visitno=request.getParameter("visitno");
		String patientid=request.getParameter("patientId");
		String dateofvisit=dtf.format(now);
		String shorthistory=request.getParameter("shorthistory");
		String complaints=request.getParameter("complaints");
		String findings=request.getParameter("findings");
		String bp=request.getParameter("BP");
		String pulse=request.getParameter("pulse");
		String respiration=request.getParameter("respiration");
		String temperature=request.getParameter("temperature");
		String painstatus=request.getParameter("painstatus");
		String nutritional=request.getParameter("nutritional");
		String treatment=request.getParameter("treatment");
		String investigation=request.getParameter("investigation");
		String lstsymptoms=request.getParameter("symptomslst");
		String lstdisorders=request.getParameter("disorderslst");
		
		
		String serial=request.getParameter("serial");
		int noofmed=Integer.parseInt(serial);
		String sno="sno";
		String medicinelist="medicinelist";
		String dosage="dosage";
		String timing="timing";
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;	
		
		
		
		
		
		
		
		 
		
		 
		 try {
			 tx = session.getTransaction();
			 tx.begin();
			 visitdata visit=new visitdata();
			 visit.setPatientid(patientid);
			 visit.setVisitno(visitno);
			 visit.setDateofvisit(dateofvisit);
			 visit.setShorthistory(shorthistory);
			 visit.setComplaints(complaints);
			 visit.setFindings(findings);
			 visit.setBp(bp);
			 visit.setPulse(pulse);
			 visit.setRespiration(respiration);
			 visit.setTemperature(temperature);
			 visit.setPainstatus(painstatus);
			 visit.setNutritional(nutritional);
			 visit.setTreatment(treatment);
			 visit.setInvestigation(investigation);
			 visit.setLstsymptoms(lstsymptoms);
			 visit.setLstdisorders(lstdisorders);
			 
			 
			 session.saveOrUpdate(visit);
			 
			 
			 
			 
			 
			 
			 for(int i=1;i<noofmed;i++)
			 
				{
			
			
			
				    prescription presc=new prescription();
			        sno=request.getParameter("sno"+i);
					medicinelist=request.getParameter("medicinelist"+i);
					dosage=request.getParameter("dosage"+i);
					timing=request.getParameter("timing"+i);
					
					System.out.println(sno+medicinelist+dosage+timing);
					
					 presc.setMedicinename(medicinelist);
					 presc.setSno(sno);
					 presc.setPatientid(patientid);
					 presc.setPresctime(timing);
					 presc.setVisitno(visitno);
					 presc.setDosage(dosage);
					
					 session.save(presc);
					 
					 
	
					
					
				}
			 
			 
			 tx.commit();
			 response.getWriter().append("<h1>Data Saved Successfully</h1>");
			 response.setHeader("Refresh", "2;url=index.jsp");
			 
			 
			 
		 } catch (Exception e) {
			 if (tx != null) {
				 tx.rollback();
			 }
			 e.printStackTrace();
		 } finally {
			 session.close();
		 }	
		 return;
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
