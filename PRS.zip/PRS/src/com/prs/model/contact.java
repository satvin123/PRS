package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "contact")
public class contact {
	
	public contact() {
		super();
	}

	@Id @GeneratedValue
	@Column(name="idcontact")
	private int id;
	
	
	@Column(name = "personalinfoid")
	   private String personalinfoid;
	
	@Column(name = "address")
	   private String address;
	
	@Column(name = "state")
	   private String state;
	
	@Column(name = "city")
	   private String city;
	
	@Column(name = "country")
	   private String country;
	
	@Column(name = "pincode")
	   private String pincode;
	
	@Column(name = "mobile")
	   private String mobile;
	
	@Column(name = "email")
	   private String email;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPersonalinfoid() {
		return personalinfoid;
	}

	public void setPersonalinfoid(String personalinfoid) {
		this.personalinfoid = personalinfoid;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	
	
	
	

}
