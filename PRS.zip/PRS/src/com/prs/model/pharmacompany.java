package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pharmacompanies")
public class pharmacompany {
	
	
	@Id @GeneratedValue
	   @Column(name = "idpharmacompanies")
	   private int id;

	   @Column(name = "pharmacompany")
	   private String pharmacompany;

	   @Column(name = "companycode")
	   private String companycode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPharmacompany() {
		return pharmacompany;
	}

	public void setPharmacompany(String pharmacompany) {
		this.pharmacompany = pharmacompany;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public pharmacompany() {
		super();
	}
	   
	   

}
