package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "prescription")
public class prescription {
	
	   @Id @GeneratedValue
	   @Column(name = "idprescription")
	   private int id;

	   @Column(name = "medicinename")
	   private String medicinename;

	   @Column(name = "dosage")
	   private String dosage;
	   
	   @Column(name = "presctime")
	   private String presctime;
	   
	   @Column(name = "sno")
	   private String sno;
	   
	   @Column(name = "patientid")
	   private String patientid;
	   
	   @Column(name = "visitno")
	   private String visitno;

	public prescription(String medicinename, String dosage, String presctime, String sno, String patientid, 
			String visitno) {
		super();
		this.medicinename = medicinename;
		this.dosage = dosage;
		this.presctime = presctime;
		this.sno = sno;
		this.patientid = patientid;
		this.visitno = visitno;
	}

	public String getVisitno() {
		return visitno;
	}

	public void setVisitno(String visitno) {
		this.visitno = visitno;
	}

	public prescription() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMedicinename() {
		return medicinename;
	}

	public void setMedicinename(String medicinename) {
		this.medicinename = medicinename;
	}

	public String getDosage() {
		return dosage;
	}

	public void setDosage(String dosage) {
		this.dosage = dosage;
	}

	public String getPresctime() {
		return presctime;
	}

	public void setPresctime(String presctime) {
		this.presctime = presctime;
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getPatientid() {
		return patientid;
	}

	public void setPatientid(String patientid) {
		this.patientid = patientid;
	}
	   
	   
	
	
	

}
