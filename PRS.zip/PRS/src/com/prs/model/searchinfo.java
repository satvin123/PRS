package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "searchinfo")

public class searchinfo {
	
	
	@Id
	@Column(name = "idpersonalinfo")
	   private String idpersonalinfo;
	
	
	@Column(name = "personalinfoid")
	   private String personalinfoid;
	
	@Column(name = "fname")
	   private String fname;
	
	@Column(name = "lname")
	   private String lname;
	
	@Column(name = "dob")
	   private String DOB;
	
	@Column(name = "gender")
	   private String gender;
	
	@Column(name = "relation")
	   private String relation;
	
	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	@Column(name = "rname")
	   private String rname;
	
	@Column(name = "age")
	   private String age;
	
	@Column(name = "city")
	   private String city;
	
	@Column(name = "mobile")
	   private String mobile;
	
	public searchinfo() {
		super();
	}

	@Column(name = "email")
	   private String email;

	public String getPersonalinfoid() {
		return personalinfoid;
	}

	public void setPersonalinfoid(String personalinfoid) {
		this.personalinfoid = personalinfoid;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
