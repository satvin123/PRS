package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "medicinepresc")

public class medicinepresc {
	
	@Id
	@Column(name = "idprescription")
	   private String idprescription;
	
	
	@Column(name = "visitno")
	   private String visitno;
	
	@Column(name = "patientid")
	   private String patientid;
	
	@Column(name = "medicinename")
	   private String medicinename;
	
	@Column(name = "dosage")
	   private String dosage;
	
	@Column(name = "presctime")
	   private String presctime;
	
	@Column(name = "idvisitdata")
	   private String idvisitdata;
	
	public String getIdvisitdata() {
		return idvisitdata;
	}

	public void setIdvisitdata(String idvisitdata) {
		this.idvisitdata = idvisitdata;
	}

	@Column(name = "dateofvisit")
	   private String dateofvisit;

	public String getIdprescription() {
		return idprescription;
	}

	public void setIdprescription(String idprescription) {
		this.idprescription = idprescription;
	}

	public String getVisitno() {
		return visitno;
	}

	public void setVisitno(String visitno) {
		this.visitno = visitno;
	}

	public String getPatientid() {
		return patientid;
	}

	public void setPatientid(String patientid) {
		this.patientid = patientid;
	}

	public String getMedicinename() {
		return medicinename;
	}

	public void setMedicinename(String medicinename) {
		this.medicinename = medicinename;
	}

	public String getDosage() {
		return dosage;
	}

	public void setDosage(String dosage) {
		this.dosage = dosage;
	}

	public String getPresctime() {
		return presctime;
	}

	public void setPresctime(String presctime) {
		this.presctime = presctime;
	}

	public String getDateofvisit() {
		return dateofvisit;
	}

	public void setDateofvisit(String dateofvisit) {
		this.dateofvisit = dateofvisit;
	}

	public medicinepresc() {
		super();
	}
	
	
	
}
