package com.prs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "eduoccupation")
public class eduOccupation {
	
	public eduOccupation() {
		super();
	}

	@Id @GeneratedValue
	@Column(name="ideduoccupation")
	private int id;
	
	
	@Column(name = "personalinfoid")
	   private String personalinfoid;
	
	@Column(name = "education")
	   private String education;
	
	@Column(name = "occupation")
	   private String occupation;
	
	@Column(name = "typeofjob")
	   private String typeofjob;
	
	@Column(name = "designation")
	   private String designation;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPersonalinfoid() {
		return personalinfoid;
	}

	public void setPersonalinfoid(String personalinfoid) {
		this.personalinfoid = personalinfoid;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getTypeofjob() {
		return typeofjob;
	}

	public void setTypeofjob(String typeofjob) {
		this.typeofjob = typeofjob;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

}





