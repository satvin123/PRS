package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.prescription;
import com.prs.model.persistence.HibernateUtil;

public class prescriptionDB {
	
	
	
	public List<prescription> listMedicines(String personalid,String visitno) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;
		List<prescription> medicinelist = null;

		try {
			tx = session.getTransaction();
			tx.begin();
			SQLQuery medicines =  session
					.createSQLQuery("Select * FROM prescription where patientid =\'"+ personalid +"\' and visitno =\'"+visitno+"\'order by medicinename");
			medicines.addEntity(prescription.class);
			medicinelist = medicines.list();
			tx.commit();
			if (!medicinelist.isEmpty()) {
				return medicinelist;
			}

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (NullPointerException ne)

		{
			ne.printStackTrace();
		} finally {
			session.close();
		}
		medicinelist.add(new prescription("","","","","",""));
		return medicinelist;

	}
	
	

}
