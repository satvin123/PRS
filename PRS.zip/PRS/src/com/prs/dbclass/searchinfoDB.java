package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.prescription;
import com.prs.model.searchinfo;
import com.prs.model.persistence.HibernateUtil;

public class searchinfoDB {
	
	
	public List<searchinfo> listInfo(String searchtext) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;
		List<searchinfo> searches = null;

		try {
			tx = session.getTransaction();
			tx.begin();
			SQLQuery search =  session
					.createSQLQuery("Select * FROM searchinfo where fname LIKE '%"+searchtext+"%' OR lname LIKE '%"+searchtext+"%' OR rname LIKE '%"+searchtext+"%' OR mobile LIKE '%"+searchtext+"%' OR email LIKE '%"+searchtext+"%'");
			search.addEntity(searchinfo.class);
			searches = search.list();
			tx.commit();
			if (!searches.isEmpty()) {
				return searches;
			}

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (NullPointerException ne)

		{
			ne.printStackTrace();
		} finally {
			session.close();
		}
		
		return null;

	}

}
