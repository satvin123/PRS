package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.persistence.HibernateUtil;

public class medicineDB {

	public List<String> listMedicine() {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;
		List<String> medicinelist;

		try {
			tx = session.getTransaction();
			tx.begin();
			medicinelist = (List<String>) session
					.createSQLQuery("Select CONCAT(medicinename,' (', medicinesalt,')') AS Medname FROM medicine order by medicinename").list();
			tx.commit();
			if (medicinelist.size() > 0) {
				return medicinelist;
			}

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (NullPointerException ne)

		{
			ne.printStackTrace();
		} finally {
			session.close();
		}
		return null;

	}
	
	
	
	
	
}
