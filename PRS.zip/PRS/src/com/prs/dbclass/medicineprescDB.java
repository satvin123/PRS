package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.medicinepresc;
import com.prs.model.searchinfo;
import com.prs.model.persistence.HibernateUtil;

public class medicineprescDB {
	
	
	public List<medicinepresc> listmedicinepresc(String searchtext , String startdate, String enddate) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;
		List<medicinepresc> searches = null;

		try {
			tx = session.getTransaction();
			tx.begin();
			SQLQuery search =  session
					.createSQLQuery("Select * FROM medicinepresc where medicinename LIKE '%"+searchtext+"%' and (dateofvisit between '"+startdate+"' and '"+enddate+"')" );
			search.addEntity(medicinepresc.class);
			searches = search.list();
			tx.commit();
			if (!searches.isEmpty()) {
				return searches;
			}

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (NullPointerException ne)

		{
			ne.printStackTrace();
		} finally {
			session.close();
		}
		
		return null;

	}

}
