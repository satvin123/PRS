package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.persistence.HibernateUtil;

public class cityDB {
	
	
	public List<String> listCity(String State_Name)
	   {
	       SessionFactory factory = HibernateUtil.getSessionFactory();       
	        Session session=factory.openSession();


	Transaction tx = null;
	      List<String> citylist;
	      
	      try{
	         tx = session.getTransaction();
	         tx.begin();
	         citylist =(List<String>) session.createSQLQuery("Select distinct cityname FROM city where state=\'"+State_Name+"\' order by cityname").list(); 
	         tx.commit();
	         if(citylist.size()>0)
	         {
	             return citylist;
	         }
	         
	         
	        
	         
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }
	      catch(NullPointerException ne)
	          
	      {ne.printStackTrace();}
	      finally {
	         session.close(); 
	      }
	       return null;
	      
	   }

}
