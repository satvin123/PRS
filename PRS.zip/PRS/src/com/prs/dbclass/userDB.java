package com.prs.dbclass;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.prescription;
import com.prs.model.userdata;
import com.prs.model.persistence.HibernateUtil;

public class userDB {
	
	
	public userdata isUserExist(String username,String password) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;
		List<userdata> users = null;

		try {
			tx = session.getTransaction();
			tx.begin();
			SQLQuery userlist =  session
					.createSQLQuery("Select * FROM userdata where username =\'"+ username +"\' and passwd =\'"+password+"\'");
			userlist.addEntity(userdata.class);
			users = (List<userdata>) userlist.list();
			tx.commit();
			if (!users.isEmpty()) {
				return users.get(0);
			}
			

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (NullPointerException ne)

		{
			ne.printStackTrace();
		} finally {
			session.close();
		}
		return null;

	}
	
	
	
	public Integer changePassword(String username,String password,String newpassword) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;
		int result=0;

		try {
			tx = session.getTransaction();
			tx.begin();
			Query query = session.createQuery("update userdata set passwd = :newpassword" +
    				" where username = :username and passwd = :passwd");
                 query.setParameter("newpassword", newpassword);
                 query.setParameter("username", username);
                 query.setParameter("passwd", password);
                  result = query.executeUpdate();
			
			tx.commit();
			
			

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} catch (NullPointerException ne)

		{
			ne.printStackTrace();
		} finally {
			session.close();
		}
		return result;

	}
	
	
	
	

}
