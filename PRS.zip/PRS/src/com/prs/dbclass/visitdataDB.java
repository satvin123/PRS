package com.prs.dbclass;

import java.util.Collections;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.prs.model.contact;
import com.prs.model.visitdata;
import com.prs.model.persistence.HibernateUtil;

public class visitdataDB {
	
	
	public String listvisitno(String personalid) {
        SessionFactory factory = HibernateUtil.getSessionFactory();
        Session session = factory.openSession();

        Transaction tx = null;
        List<String> CodeList;

        try {
            tx = session.getTransaction();
            tx.begin();
            CodeList = (List<String>) session.createSQLQuery("Select visitno FROM visitdata where patientid=" + "\'" + personalid + "\'").list();
            tx.commit();
            if (CodeList.size() > 0) {
                return Collections.max(CodeList);
            }

        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } catch (NullPointerException ne) {
            ne.printStackTrace();
        } finally {
            session.close();
        }
        return "0";

    }
	
	
	public List<Object[]> listvisit(String personalid) {
        SessionFactory factory = HibernateUtil.getSessionFactory();
        Session session = factory.openSession();

        Transaction tx = null;
        List<Object[]> CodeList;

        try {
            tx = session.getTransaction();
            tx.begin();
            CodeList = (List<Object[]>) session.createSQLQuery("Select v.idvisitdata, v.visitno, v.dateofvisit FROM visitdata v where v.patientid=" + "\'" + personalid + "\'").list();
            tx.commit();
            
            
            if (CodeList.size() > 0) {
                return CodeList;
            }

        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } catch (NullPointerException ne) {
            ne.printStackTrace();
        } finally {
            session.close();
        }
        
        return null;

    }
	
	
	
	public visitdata getvisitdata(Integer idvisitdata)
    {
        
        SessionFactory factory = HibernateUtil.getSessionFactory();
        Session session = factory.openSession();
        
        visitdata visit = null;
        
        try{
        	
            visit=(visitdata)session.get(visitdata.class, idvisitdata);
	       }
        
        catch(NullPointerException ne)
        
	      {ne.printStackTrace();}
        
        catch(Exception sqlException) {
            if(null != session.getTransaction()) {
                System.out.println("\n.......Transaction Is Being Rolled Back.......");
                session.getTransaction().rollback();
            }
            sqlException.printStackTrace();
        }
        
        finally {
	      
        if(session != null) {
            session.close();
        }
        }
	       
        
        return visit;
        
        
    }
	
	
	
	
	
	

}
